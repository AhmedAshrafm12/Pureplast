<?php
use modules\clients;
if($_SERVER["REQUEST_METHOD"] == "GET"){
   
    include "../../includes/connect.php";
    include "../../modules/clients.php";
    $client = new clients($conn);
     echo json_encode($client->get_by_id());

     
}



?>