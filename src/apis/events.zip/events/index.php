<?php
use modules\event;
if($_SERVER["REQUEST_METHOD"] == "GET"){
   
    include "../../includes/connect.php";
    include "../../modules/event.php";
    $event = new event($conn);
     echo json_encode($event->index());

     
}



?>