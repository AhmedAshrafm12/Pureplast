<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if($_SERVER['REQUEST_METHOD']  == "POST"){

    
    // //Load Composer's autoloader
    // $from = "ahmedashrafdev99@gmail.com"; // sender must be valid
    // $subject = "subject";
    // $message = 'mail from'.$from.'sender';
    include "../../includes/init.php";
    
    $from = filter_var($_POST['email'], FILTER_SANITIZE_SPECIAL_CHARS);
    $subject = filter_var($_POST['subject'], FILTER_SANITIZE_SPECIAL_CHARS);
    $message = filter_var($_POST['body'], FILTER_SANITIZE_SPECIAL_CHARS);
    $to = "shaimaagamal772@gmail.com";
    // send mail
    $headers = "From: <$from>" . "\n";
    $headers .= "MIME-Version: 1.0\n" ; 
    $headers .= "Content-Type: text/html; charset=\"iso-8859-1\"\n";


    if(mail($to,$subject,$message,$headers)){
        response(true , 200 , "mail sent successfully !" );
    };

}

?>